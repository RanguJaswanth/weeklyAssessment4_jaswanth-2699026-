package com.school.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.school.demo.Entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    // Custom query methods (optional)
    
    // Example: Find a student by email
    Student findByEmail(String email);

    // Example: Find students by name
    List<Student> findByName(String name);

    // You can add more custom queries as needed
}
