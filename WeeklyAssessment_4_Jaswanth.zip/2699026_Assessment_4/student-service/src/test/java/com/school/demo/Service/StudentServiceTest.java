package com.school.demo.Service;
import com.school.demo.Entity.Student;
import com.school.demo.Repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    private Student student;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        student = new Student("John Doe", "john@example.com", new Date(), 85.5);
        student.setId(1);
    }

    @Test
    void testAddStudent() {
        when(studentRepository.save(student)).thenReturn(student);

        Student saved = studentService.addStudent(student);

        assertNotNull(saved);
        assertEquals("John Doe", saved.getName());
        verify(studentRepository, times(1)).save(student);
    }

    @Test
    void testGetAllStudents() {
        when(studentRepository.findAll()).thenReturn(Arrays.asList(student));

        List<Student> students = studentService.getAllStudents();

        assertEquals(1, students.size());
        verify(studentRepository, times(1)).findAll();
    }

    @Test
    void testGetStudentById() {
        when(studentRepository.findById(1)).thenReturn(Optional.of(student));

        Optional<Student> found = studentService.getStudentById(1);

        assertTrue(found.isPresent());
        assertEquals("john@example.com", found.get().getEmail());
    }

    @Test
    void testUpdateStudent() {
        when(studentRepository.save(student)).thenReturn(student);

        Student updated = studentService.updateStudent(1, student);

        assertEquals(1, updated.getId());
        verify(studentRepository, times(1)).save(student);
    }

    @Test
    void testDeleteStudent() {
        doNothing().when(studentRepository).deleteById(1);

        studentService.deleteStudent(1);

        verify(studentRepository, times(1)).deleteById(1);
    }
}
